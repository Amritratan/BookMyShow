package com.example.bookmyshowJune.Exception;

public class MovieNotFound extends Exception{

    public MovieNotFound(String message) {
        super(message);
    }
}
