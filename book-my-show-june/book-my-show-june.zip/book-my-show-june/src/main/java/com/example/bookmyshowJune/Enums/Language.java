package com.example.bookmyshowJune.Enums;

public enum Language {

    ENGLISH,
    HINDI,
    PUNJABI,
    TELUGU,
    MALLAYALAM,
    TAMIL,
    MARATHI,
    BHOJPURI,
    KANNADA
}
