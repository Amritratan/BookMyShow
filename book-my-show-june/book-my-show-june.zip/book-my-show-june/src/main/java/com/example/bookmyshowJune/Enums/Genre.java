package com.example.bookmyshowJune.Enums;

public enum Genre {
    COMEDY,
    ROMANTIC,
    THRILLER,
    ACTION,
    SCIFICTION,
    HORROR,
    ANIMATED,
    ANIME,
    CRIMINAL,
    DOCUMENTARY
}
