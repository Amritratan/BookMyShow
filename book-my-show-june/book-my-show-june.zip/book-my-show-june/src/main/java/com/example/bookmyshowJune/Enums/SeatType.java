package com.example.bookmyshowJune.Enums;

public enum SeatType {
    CLASSIC,
    PREMIUM
}
