package com.example.bookmyshowJune.Dtos.RequestDto;

import lombok.Data;

@Data
public class TheaterEntryDto {

    private String name;
    private String location;
}
