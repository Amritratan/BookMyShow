package com.example.bookmyshowJune.Repository;

import com.example.bookmyshowJune.Models.TheaterSeat;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TheaterSeatRepository extends JpaRepository<TheaterSeat,Integer> {
}
