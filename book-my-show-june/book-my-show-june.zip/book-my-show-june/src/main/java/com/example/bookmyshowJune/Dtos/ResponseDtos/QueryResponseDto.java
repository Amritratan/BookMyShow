package com.example.bookmyshowJune.Dtos.ResponseDtos;

import lombok.Data;

@Data
public class QueryResponseDto {

    private  int movie_id;
    private int count;

}
