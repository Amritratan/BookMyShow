package com.example.bookmyshowJune.Exception;

public class ShowNotFound extends Exception{

    public ShowNotFound(String message) {
        super(message);
    }
}
