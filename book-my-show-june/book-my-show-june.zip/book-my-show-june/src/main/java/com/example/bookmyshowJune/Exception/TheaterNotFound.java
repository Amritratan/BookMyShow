package com.example.bookmyshowJune.Exception;

public class TheaterNotFound extends Exception{

    public TheaterNotFound(String message) {
        super(message);
    }
}
