package com.example.bookmyshowJune;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookMyShowJuneApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookMyShowJuneApplication.class, args);
	}

}
