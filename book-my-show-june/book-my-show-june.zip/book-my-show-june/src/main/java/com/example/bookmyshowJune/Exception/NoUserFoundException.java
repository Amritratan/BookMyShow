package com.example.bookmyshowJune.Exception;

public class NoUserFoundException extends Exception{

    public NoUserFoundException(String message) {
        super(message);
    }
}
