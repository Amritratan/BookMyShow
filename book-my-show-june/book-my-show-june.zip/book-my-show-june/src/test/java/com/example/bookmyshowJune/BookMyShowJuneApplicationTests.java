package com.example.bookmyshowJune;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowJuneApplicationTests {

	@Test
	void contextLoads() {
	}

}
